package com.example.stroopeffectapp;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

public class GameOverDialog extends Dialog {

    private final Context context;
    private Button restartButton;
    private TextView dialogScoreTextview;

    public GameOverDialog(@NonNull Context context) {
        super(context);
        this.context = context;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_game_over);
        setupViewsAndListeners();

    }

    private void setupViewsAndListeners() {
        restartButton = findViewById(R.id.restartButton);
        dialogScoreTextview = findViewById(R.id.dialogScoreTextView);

        dialogScoreTextview.setText(((MainActivity) context).getScore());

        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ((MainActivity) context).resetGame();

                dismiss();
            }
        });
    }
}
