package com.example.stroopeffectapp;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private final ArrayList<String> colorNames = new ArrayList<>();
    private final ArrayList<Integer> colorValues = new ArrayList<>();

    private Random random;

    //Textviews
    private TextView scoreTextView;
    private TextView colorTextView;

    //Buttons
    private Button redButton;
    private Button orangeButton;
    private Button blueButton;
    private Button greenButton;
    private Button purpleButton;
    private Button yellowButton;

    private View.OnClickListener buttonOnClickListener;

    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        random = new Random();
        setupViewsAndListeners();
        populateBothArraylists();
        getRandomColor();
    }

    private void setupViewsAndListeners() {
        //Textviews
        scoreTextView = findViewById(R.id.scoreTextView);
        scoreTextView.setText("Score: " + score);
        colorTextView = findViewById(R.id.colortextView);

        //Buttons
        redButton = findViewById(R.id.RedButton);
        orangeButton = findViewById(R.id.OrangeButton);
        blueButton = findViewById(R.id.BlueButton);
        greenButton = findViewById(R.id.GreenButton);
        purpleButton = findViewById(R.id.PurpleButton);
        yellowButton = findViewById(R.id.YellowButton);


        buttonOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Convert background to drawable
                ColorDrawable col = (ColorDrawable) v.getBackground();

                //Get color of drawable
                int color = col.getColor();

                if (color == colorTextView.getCurrentTextColor()) {

                    score++;
                    scoreTextView.setText("Score: " + score);
                    getRandomColor();
                } else {
                    GameOverDialog gameOverDialog = new GameOverDialog(MainActivity.this);
                    gameOverDialog.setCancelable(false);
                    gameOverDialog.show();
                }
            }
        };

        redButton.setOnClickListener(buttonOnClickListener);
        orangeButton.setOnClickListener(buttonOnClickListener);
        blueButton.setOnClickListener(buttonOnClickListener);
        greenButton.setOnClickListener(buttonOnClickListener);
        purpleButton.setOnClickListener(buttonOnClickListener);
        yellowButton.setOnClickListener(buttonOnClickListener);

    }


    private void populateBothArraylists() {

        //Add color names to the arraylist
        colorNames.add("Red");
        colorNames.add("Orange");
        colorNames.add("Blue");
        colorNames.add("Yellow");
        colorNames.add("Purple");
        colorNames.add("Green");

        //Add color values to the arraylist
        colorValues.add(ContextCompat.getColor(this, R.color.colorRed));
        colorValues.add(ContextCompat.getColor(this, R.color.colorOrange));
        colorValues.add(ContextCompat.getColor(this, R.color.colorBlue));
        colorValues.add(ContextCompat.getColor(this, R.color.colorYellow));
        colorValues.add(ContextCompat.getColor(this, R.color.colorGreen));
        colorValues.add(ContextCompat.getColor(this, R.color.colorPurple));
    }

    private void getRandomColor() {

        //Add a bit more randomness
        Collections.shuffle(colorNames);
        Collections.shuffle(colorValues);

        //using a random number to get a random color from the arraylist
        int randomColor = random.nextInt(colorNames.size());
        String colorChosen = colorNames.get(randomColor);

        //Set this random color to be the text that is shown at the bottom.
        colorTextView.setText(colorChosen);

        //Choose an actual color to be randomly generated for the text
        int randomColorTextColor = random.nextInt(colorValues.size());
        colorTextView.setTextColor(colorValues.get(randomColorTextColor));
    }

    public void resetGame() {
        score = 0;
        scoreTextView.setText("Score: " + score);
        getRandomColor();
    }

    public String getScore() {
        return scoreTextView.getText().toString();
    }
}